__version__ = "0.0.1"
__author__ = "Epsilon Luoo"
__email__ = "epsilon_luoo@outlook.com"

print(f"""
MPOne Version: {__version__}
Author: {__author__}
Email: {__email__}
""")