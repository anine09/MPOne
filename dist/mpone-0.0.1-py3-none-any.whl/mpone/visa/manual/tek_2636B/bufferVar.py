class bufferVar:
    def appendmode(self):
        pass
    def basetimestamp(self):
        pass
    def cachemode(self):
        pass
    def capacity(self):
        pass
    def clear(self):
        pass
    def clearcache(self):
        pass
    def collectsourcevalues(self):
        pass
    def collecttimestamps(self):
        pass
    def fillcount(self):
        pass
    def fillmode(self):
        pass
    def measurefunctions(self):
        pass
    def n(self):
        pass
    def readings(self):
        pass
    def sourcefunctions(self):
        pass
    def sourceoutputstates(self):
        pass
    def sourceranges(self):
        pass
    def sourcecalues(self):
        pass
    def statuses(self):
        pass
    def timestampresolution(self):
        pass
    def timestamps(self):
        pass