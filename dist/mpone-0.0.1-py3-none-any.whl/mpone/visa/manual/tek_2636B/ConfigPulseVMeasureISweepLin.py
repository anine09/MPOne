def ConfigPulseVMeasureISweepLin():
    pass