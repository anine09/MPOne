class io:
    def close(self):
        pass
    def flush(self):
        pass
    def input(self):
        pass
    def open(self):
        pass
    def read(self):
        pass
    def type(self):
        pass
    def write(self):
        pass
