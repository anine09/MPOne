def printbuffer():
    pass