def gm_vsweep():
    pass