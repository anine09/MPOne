def QueryPulseConfig():
    pass