def fileVar_read():
    pass