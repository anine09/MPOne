def opc():
    pass