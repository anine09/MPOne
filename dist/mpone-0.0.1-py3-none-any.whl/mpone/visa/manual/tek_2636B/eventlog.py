class eventlog:
    def all(self):
        pass
    def clear(self):
        pass
    def count(self):
        pass
    def enable(self):
        pass
    def next(self):
        pass
    def overwritemethod(self):
        pass