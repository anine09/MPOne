def settimezone():
    pass