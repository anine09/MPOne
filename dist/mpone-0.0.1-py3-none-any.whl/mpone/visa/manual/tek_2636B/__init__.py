from .smu import smu

smu = smu("a")

def smu_reset():
    smu.reset()

