def meminfo():
    pass