def fileVar_write():
    pass