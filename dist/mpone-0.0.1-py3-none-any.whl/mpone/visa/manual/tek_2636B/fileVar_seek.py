def fileVar_seek():
    pass