def delay():
    pass