class digio:
    def readbit(self):
        pass
    def readport(self):
        pass
    def trigger_assert(self):
        pass
    def trigger_clear(self):
        pass
    def trigger_EVENT_ID(self):
        pass
    def trigger_mode(self):
        pass
    def trigger_overrun(self):
        pass
    def trigger_pulsewidth(self):
        pass
    def trigger_release(self):
        pass
    def trigger_reset(self):
        pass
    def trigger_stimulus(self):
        pass
    def trigger_wait(self):
        pass
    def writebit(self):
        pass
    def writeport(self):
        pass
    def writeprotect(self):
        pass