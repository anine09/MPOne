def i_leakage_threshold():
    pass