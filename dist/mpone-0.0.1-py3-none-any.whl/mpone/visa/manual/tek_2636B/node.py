class node:
    def execute(self):
        pass
    def getglobal(self):
        pass
    def setglobal(self):
        pass