def gm_isweep():
    pass