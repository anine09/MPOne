def reset():
    pass