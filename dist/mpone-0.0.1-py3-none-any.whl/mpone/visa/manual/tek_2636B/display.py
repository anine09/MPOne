class display:
    def clear(self):
        pass
    def getannunciators(self):
        pass
    def getcursor(self):
        pass
    def getlastkey(self):
        pass
    def gettext(self):
        pass
    def inputvalue(self):
        pass
    def loadmenu_add(self):
        pass
    def loadmenu_catalog(self):
        pass
    def loadmenu_delete(self):
        pass
    def locallockout(self):
        pass
    def menu(self):
        pass
    def numpad(self):
        pass
    def prompt(self):
        pass
    def screen(self):
        pass
    def sendkey(self):
        pass
    def setcursor(self):
        pass
    def settext(self):
        pass
    def smu_digits(self):
        pass
    def smu_limit_func(self):
        pass
    def smu_measure_func(self):
        pass
    def trigger_clear(self):
        pass
    def trigger_EVENT_ID(self):
        pass
    def trigger_overrun(self):
        pass
    def trigger_wait(self):
        pass
    def waitkey(self):
        pass