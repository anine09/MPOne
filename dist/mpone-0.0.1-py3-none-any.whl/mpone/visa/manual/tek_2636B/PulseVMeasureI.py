def PulseVMeasureI():
    pass