class timer:
    def measure_t(self):
        pass
    def reset(self):
        pass