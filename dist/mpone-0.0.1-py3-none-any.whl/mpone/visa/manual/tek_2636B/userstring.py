class userstring:
    def add(self):
        pass
    def catalog(self):
        pass
    def delete(self):
        pass
    def get(self):
        pass