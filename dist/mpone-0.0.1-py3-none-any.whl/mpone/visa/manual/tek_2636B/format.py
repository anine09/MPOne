class format:
    def asciiprecision(self):
        pass
    def byteorder(self):
        pass
    def data(self):
        pass