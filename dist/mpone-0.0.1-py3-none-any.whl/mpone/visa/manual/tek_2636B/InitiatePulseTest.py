def InitiatePulseTest():
    pass