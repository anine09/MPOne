class setup:
    def poweron(self):
        pass
    def recall(self):
        pass
    def save(self):
        pass