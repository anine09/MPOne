class errorqueue:
    def clear(self):
        pass
    def count(self):
        pass
    def next(self):
        pass