def ConfigPulseIMeasureVSweepLog():
    pass