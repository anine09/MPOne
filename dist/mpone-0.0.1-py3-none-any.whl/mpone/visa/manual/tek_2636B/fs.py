class fs:
    def chdir(self):
        pass
    def cwd(self):
        pass
    def is_dir(self):
        pass
    def is_file(self):
        pass
    def mkdir(self):
        pass
    def readdir(self):
        pass
    def rmdir(self):
        pass