def MODE_(self):
    pass