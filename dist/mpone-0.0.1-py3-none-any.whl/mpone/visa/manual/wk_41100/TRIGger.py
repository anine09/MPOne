def TRIGger(self):
    pass