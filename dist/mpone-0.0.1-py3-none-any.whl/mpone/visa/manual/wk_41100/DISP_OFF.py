def DISP_OFF(self):
    pass