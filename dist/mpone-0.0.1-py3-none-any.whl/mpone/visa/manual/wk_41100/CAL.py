class CAL:
    def OC_TRIM(self):
        pass
    def SC_TRIM(self):
        pass
    def RESult_(self):
        pass