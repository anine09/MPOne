def DISP_ON(self):
    pass