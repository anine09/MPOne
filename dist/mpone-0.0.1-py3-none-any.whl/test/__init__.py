import test.Automatic_Instrument_Detection
import test.Live_Data_Plot

# version 0.0.1
__version__ = "0.0.1"

# Attention
print("Attention! \"Live Data Plot\" function is still in Early"
      " Development Version, it is Unstable and supports only graphical interface")

