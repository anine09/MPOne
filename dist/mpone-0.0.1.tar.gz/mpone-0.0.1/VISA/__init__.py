import Automatic_Instrument_Detection

# version 0.0.1
__version__ = "0.0.1"

# Attention
print("Attention! \"Live Data Plot\" function is still in Early"
      " Development Version,\n"+"it is Unstable and supports only graphical interface.")
