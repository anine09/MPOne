def waitcomplete():
    pass