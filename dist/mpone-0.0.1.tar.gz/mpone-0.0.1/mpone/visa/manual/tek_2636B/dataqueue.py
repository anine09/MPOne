class dataqueue:
    def add(self):
        pass
    def CAPACITY(self):
        pass
    def clear(self):
        pass
    def count(self):
        pass
    def next(self):
        pass