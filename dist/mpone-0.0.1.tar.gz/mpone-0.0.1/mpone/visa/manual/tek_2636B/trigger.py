class trigger:
    def blender_clear(self):
        pass
    def blender_EVENT_ID(self):
        pass
    def blender_orenable(self):
        pass
    def blender_overrun(self):
        pass
    def blender_reset(self):
        pass
    def blender_stimulus(self):
        pass
    def blender_wait(self):
        pass
    def clear(self):
        pass
    def EVENT_ID(self):
        pass
    def generator_assert(self):
        pass
    def generator_EVENT_ID(self):
        pass
    def timer_clear(self):
        pass
    def timer_count(self):
        pass
    def timer_delay(self):
        pass
    def timer_delaylist(self):
        pass
    def timer_EVENT_ID(self):
        pass
    def timer_overrun(self):
        pass
    def timer_passthrough(self):
        pass
    def timer_reset(self):
        pass
    def timer_stimulus(self):
        pass
    def timer_wait(self):
        pass
    def wait(self):
        pass