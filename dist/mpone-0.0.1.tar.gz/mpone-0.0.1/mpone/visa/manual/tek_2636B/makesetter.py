def makesetter():
    pass