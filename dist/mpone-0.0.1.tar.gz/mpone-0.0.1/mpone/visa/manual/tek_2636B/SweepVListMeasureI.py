def SweepVListMeasureI():
    pass