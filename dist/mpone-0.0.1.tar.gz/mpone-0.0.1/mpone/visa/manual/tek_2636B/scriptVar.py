class scriptVar:
    def autorun(self):
        pass
    def list(self):
        pass
    def name(self):
        pass
    def run(self):
        pass
    def save(self):
        pass
    def source(self):
        pass