def ConfigPulseIMeasureV():
        pass