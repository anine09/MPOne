def i_leakage_measure():
    pass