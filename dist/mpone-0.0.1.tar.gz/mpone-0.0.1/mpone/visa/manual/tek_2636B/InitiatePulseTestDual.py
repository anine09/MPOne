def InitiatePulseTestDual():
    pass