class bit:
    def bitand(self):
        pass
    def bitor(self):
        pass
    def bitxor(self):
        pass
    def clear(self):
        pass
    def get(self):
        pass
    def getfiled(self):
        pass
    def set(self):
        pass
    def setfield(self):
        pass
    def test(self):
        pass
    def toggle(self):
        pass