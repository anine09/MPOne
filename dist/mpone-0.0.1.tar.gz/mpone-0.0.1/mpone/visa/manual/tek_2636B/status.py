class status:
    def condition(self):
        pass
    def measurement_(self):
        pass
    def measurement_buffer_available_(self):
        pass
    def measurement_current_limit_(self):
        pass
    def measurement_instrument_(self):
        pass
    def measurement_instrument_smu_(self):
        pass
    def measurement_reading_overflow_(self):
        pass
    def measurement_voltage_limit_(self):
        pass
    def node_enable(self):
        pass
    def node_event(self):
        pass
    def operation_(self):
        pass
    def operation_calibrating_(self):
        pass
    def operation_instrument_(self):
        pass
    def operation_instrument_digio_(self):
        pass
    def operation_instrument_digio_trigger_overrun_(self):
        pass
    def operation_instrument_lan(self):
        pass
    def operation_instrument_lan_trigger_overrun_(self):
        pass
    def operation_instrument_smu_(self):
        pass
    def operation_instrument_smu_trigger_overrun(self):
        pass
    def operation_instrument_trigger_blender_(self):
        pass
    def operation_instrument_trigger_blender_tirgger_overrun_(self):
        pass
    def operation_instrument_trigger_timer_(self):
        pass
    def operation_instrument_trigger_timer_trigger_overrun_(self):
        pass
    def operation_instrument_tsplink_(self):
        pass
    def operation_instrument_tsplink_trigger_overrun_(self):
        pass
    def operation_measuring_(self):
        pass
    def operation_remote_(self):
        pass
    def operation_sweeping_(self):
        pass
    def operation_trigger_overrun_(self):
        pass
    def operation_user_(self):
        pass
    def questionable_(self):
        pass
    def questionable_calibration_(self):
        pass
    def questionable_instrument_(self):
        pass
    def questionable_instrument_smu_(self):
        pass
    def questionable_over_temperature_(self):
        pass
    def questionable_unstable_output_(self):
        pass
    def request_enable(self):
        pass
    def request_event(self):
        pass
    def reset(self):
        pass
    def standard_(self):
        pass
    def system_(self):
        pass
    def system2_(self):
        pass
    def system3_(self):
        pass
    def system4_(self):
        pass
    def system5_(self):
        pass