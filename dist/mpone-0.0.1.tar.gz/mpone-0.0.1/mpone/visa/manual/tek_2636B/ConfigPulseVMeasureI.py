def ConfigPulseVMeasureI():
    pass