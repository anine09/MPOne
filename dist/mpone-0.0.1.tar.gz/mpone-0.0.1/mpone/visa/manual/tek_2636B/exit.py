def exit():
    pass