def gettimezone():
    pass