def ConfigPulseIMeasureVSweepLin():
    pass