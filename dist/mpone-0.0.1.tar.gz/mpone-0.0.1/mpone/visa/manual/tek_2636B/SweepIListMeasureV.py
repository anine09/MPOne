def SweepIListMeasureV():
    pass