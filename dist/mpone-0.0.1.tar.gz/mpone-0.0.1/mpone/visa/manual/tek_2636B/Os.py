class Os:
    def remove(self):
        pass
    def rename(self):
        pass
    def time(self):
        pass