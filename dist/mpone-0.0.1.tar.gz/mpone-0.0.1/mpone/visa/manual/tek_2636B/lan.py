class lan:
    def applysettings(self):
        pass
    def autoconnect(self):
        pass
    def config_dns_address(self):
        pass
    def config_dns_domain(self):
        pass
    def config_dns_dynamic(self):
        pass
    def config_dns_hostname(self):
        pass
    def config_dns_verify(self):
        pass
    def config_duplex(self):
        pass
    def config_gateway(self):
        pass
    def config_ipaddress(self):
        pass
    def config_method(self):
        pass
    def config_speed(self):
        pass
    def config_subnetmask(self):
        pass
    def linktimeout(self):
        pass
    def lxidomain(self):
        pass
    def nagle(self):
        pass
    def reset(self):
        pass
    def restoredefaults(self):
        pass
    def status_dns_address(self):
        pass
    def status_dns_name(self):
        pass
    def status_duplex(self):
        pass
    def status_gateway(self):
        pass
    def status_ipaddress(self):
        pass
    def status_macaddress(self):
        pass
    def status_port_dst(self):
        pass
    def status_port_rawsocket(self):
        pass
    def status_port_telnet(self):
        pass
    def status_port_vxi11(self):
        pass
    def status_speed(self):
        pass
    def status_subnetmask(self):
        pass
    def timewait(self):
        pass
    def trigger_assert(self):
        pass
    def trigger_clear(self):
        pass
    def trigger_connect(self):
        pass
    def trigger_connected(self):
        pass
    def trigger_disconnect(self):
        pass
    def trigger_EVENT_ID(self):
        pass
    def trigger_ipaddress(self):
        pass
    def trigger_mode(self):
        pass
    def trigger_overrun(self):
        pass
    def trigger_protocol(self):
        pass
    def trigger_pseudostate(self):
        pass
    def trigger_stimulus(self):
        pass
    def trigger_wait(self):
        pass