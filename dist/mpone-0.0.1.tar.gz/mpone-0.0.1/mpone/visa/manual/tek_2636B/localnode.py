class localnode:
    def autolinefreq(self):
        pass
    def description(self):
        pass
    def license(self):
        pass
    def linefreq(self):
        pass
    def model(self):
        pass
    def password(self):
        pass
    def passwordmode(self):
        pass
    def prompts(self):
        pass
    def prompts4882(self):
        pass
    def reset(self):
        pass
    def revision(self):
        pass
    def serialno(self):
        pass
    def showerrors(self):
        pass