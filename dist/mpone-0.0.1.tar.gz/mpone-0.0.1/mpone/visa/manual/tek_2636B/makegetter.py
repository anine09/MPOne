def makegetter():
    pass