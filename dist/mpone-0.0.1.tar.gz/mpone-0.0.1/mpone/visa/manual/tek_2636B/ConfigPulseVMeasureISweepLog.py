def ConfigPulseVMeasureISweepLog():
    pass