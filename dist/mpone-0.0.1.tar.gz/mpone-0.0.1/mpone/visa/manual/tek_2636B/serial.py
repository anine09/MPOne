class serial:
    def databits(self):
        pass
    def flowcontrol(self):
        pass
    def parity(self):
        pass
    def read(self):
        pass
    def write(self):
        pass