def fileVar_flush():
    pass