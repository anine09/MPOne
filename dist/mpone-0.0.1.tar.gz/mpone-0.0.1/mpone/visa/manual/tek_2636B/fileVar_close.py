def fileVar_close():
    pass