class tspnet:
    def clear(self):
        pass
    def connect(self):
        pass
    def disconnect(self):
        pass
    def execute(self):
        pass
    def idn(self):
        pass
    def read(self):
        pass
    def readavailable(self):
        pass
    def reset(self):
        pass
    def termination(self):
        pass
    def timeout(self):
        pass
    def tsp_abort(self):
        pass
    def tsp_abortonconnect(self):
        pass
    def tsp_rbtablecopy(self):
        pass
    def tsp_runscript(self):
        pass
    def wirte(self):
        pass