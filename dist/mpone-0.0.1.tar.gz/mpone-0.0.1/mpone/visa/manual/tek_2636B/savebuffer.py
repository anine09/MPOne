def savebuffer():
    pass