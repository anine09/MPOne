from requests import delete


class script:
    def anonymous(self):
        pass
    def delete(self):
        pass
    def factory_catalog(self):
        pass
    def load(self):
        pass
    def new(self):
        pass
    def newautorun(self):
        pass
    def restore(self):
        pass
    def run(self):
        pass
    def user_catalog(self):
        pass