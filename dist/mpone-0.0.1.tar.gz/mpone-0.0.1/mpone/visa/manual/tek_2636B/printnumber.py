def printnumber():
    pass