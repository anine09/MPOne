def settime():
    pass