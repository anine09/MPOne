def SweepVLogMeasureI():
    pass