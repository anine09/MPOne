class beeper:
    def beep(self):
        pass
    def enable(self):
        pass