class gpib:
    def address(self):
        pass