from . import wk_41100
from . import tek_2636B

__support_instrument__ = """
WAYNE KERR, 41100
"""