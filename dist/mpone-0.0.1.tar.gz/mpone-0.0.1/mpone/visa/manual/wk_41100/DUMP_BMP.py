def DUMP_BMP(self):
    pass