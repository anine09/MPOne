class BIN:
    def MODE(self):
        pass
    def MODE_(self):
        pass
    def TRIGger(self):
        pass
    def TYPE(self):
        pass
    def TYPE_(self):
        pass
    def FREQuency(self):
        pass
    def FREQuency_(self):
        pass
    def LEVel(self):
        pass
    def LEVeL_(self):
        pass
    def SPEED(self):
        pass
    def SPEED_(self):
        pass
    def RANGE(self):
        pass
    def RANGE_(self):
        pass
    def EQU_CCT(self):
        pass
    def EQU_CCT_(self):
        pass
    def FUNC1(self):
        pass
    def FUNC1_(self):
        pass
    def FUNC2(self):
        pass
    def FUNC2_(self):
        pass
    def BIAS(self):
        pass
    def BIAS_STAT_(self):
        pass
    def LIMit1(self):
        pass
    def LIMit1_(self):
        pass
    def LIMit2(self):
        pass
    def LIMit2_(self):
        pass
    def NOMinal1(self):
        pass
    def NOMinal1_(self):
        pass
    def NOMinal2(self):
        pass
    def NOMinal2_(self):
        pass
    def HI_LIMit1(self):
        pass
    def HI_LIMit1_(self):
        pass
    def HI_LIMit2(self):
        pass
    def HI_LIMit2_(self):
        pass
    def LO_LIMit1(self):
        pass
    def LO_LIMit1_(self):
        pass
    def LO_LIMit2(self):
        pass
    def LO_LIMit2_(self):
        pass
    def MAX_LIMit(self):
        pass
    def MAX_LIMit_(self):
        pass
    def MIN_LIMit(self):
        pass
    def MIN_LIMit_(self):
        pass
    def DEL_LAST(self):
        pass
    def DEL_ALL(self):
        pass
    def BIN0_COUNT_(self):
        pass
    def BIN1_COUNT_(self):
        pass
    def BIN2_COUNT_(self):
        pass
    def BIN3_COUNT_(self):
        pass
    def BIN4_COUNT_(self):
        pass
    def BIN5_COUNT_(self):
        pass
    def BIN6_COUNT_(self):
        pass
    def BIN7_COUNT_(self):
        pass
    def BIN8_COUNT_(self):
        pass
    def BIN9_COUNT_(self):
        pass
    def TOTALS_(self):
        pass